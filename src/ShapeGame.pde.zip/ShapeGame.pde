// Ruby Jacobsen | Shape Game | 9 Sept 2024
import processing.sound.*;
int x, y, score, tx, ty, tw, speed;
PImage realcat, bg01, target1;
SoundFile meow;

void setup() { // setup runs once at startup
  size(400, 400);
  background(#418954);
  realcat = loadImage("realcat.png");
  bg01 = loadImage("pond.png");
  target1 = loadImage("fis.png");
  meow = new SoundFile(this, "MEOW.wav");
  x = width/2;
  y = height/2;
  score = 0;
  tx = int(random(width));
  ty = int(random(height));
  tw = 100;
  speed = 0;
}

void draw() { // draw runs on a 30 fps rate
  frameRate(speed + 30);
  background(bg01);
  println(dist(x, y, tx, ty));
  score();

  if (keyPressed) {
    if (key == 'w' || key == 'W') {
      y=y -10;
    } else if (key == 's' || key == 'S') {
      y=y +10;
    } else if (key == 'a' || key == 'A') {
      x=x -10;
    } else if (key == 'd' || key == 'D') {
      x=x +10;
    }
  }
  target();
  fill(0);
  imageMode(CENTER);
  image(realcat, x, y);
  //ellipse(x, y, 50, 50);
}

void keyPressed() {
  if (key == CODED) {
    if (keyCode == UP) {
      y = y - 10;
    } else if (keyCode == DOWN) {
      y = y + 10;
    } else if (keyCode == LEFT) {
      x = x - 10;
    } else if (keyCode == RIGHT) {
      x = x + 10;
    }
  }
}

void score() {
  rectMode(CENTER);
  fill(127);
  rect(width/2, 20, width, 40);
  fill(255);
  textSize(30);
  text("Score:" + score, 20, 35);
}

void target() {
  //rectMode(CENTER);
  //fill(255, 22, 22);
  //rect(tx, ty, tw, tw);
  imageMode(CENTER);
  image(target1, tx, ty);
  tw--;
  target1.resize(tw, tw);
  if (tw < 1) {
    gameOver();
  }
  if (dist(x, y, tx, ty)<25+tw/2) {
    score = score + 100;
    tx = int(random(width));
    ty = int(random(height));
    tw = 100;
    speed++;
  }
}

void gameOver() {
  background(0);
  textAlign(CENTER);
  textSize(40);
  fill(255);
  text("Game Over!", width/2, height/2);
  text("Score:"+ score, width/2, height/2+50);
  noLoop();
}
